//
//  ViewController.swift
//  DemoAds
//
//  Created by MacBook Pro on 05/12/2023.
//

import UIKit
import GoogleMobileAds

class ViewController: UIViewController {
    
    //For Interstitial Ad
    private var interstitial: GADInterstitialAd?
    
    //For Banner Ad
    @IBOutlet weak var bannerView: GADBannerView!
    
    //For Reward Ad
    private var rewardedInterstitialAd: GADRewardedInterstitialAd?
    
    private var coinCount = 0
    @IBOutlet weak var playAgainButton: UIButton!
    @IBOutlet weak var coinCountLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bannerView.adUnitID = "ca-app-pub-3940256099942544/2934735716"
        bannerView.rootViewController = self
        bannerView.delegate = self
        bannerView.load(GADRequest())
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // For Reward Ad
        addloadrewardedInterstitialAd()
        
        // Load Interstitial Ad
        loadInterstitialAd()
        
        
    }
    
    // For Interstitial Ad
    
    @IBAction func doSomething(_ sender: Any) {
        showInterstitialAd()
    }
    
    // For Reward Ad
    
    @IBAction func playAgain(_ sender: AnyObject) {
        if let ad = self.rewardedInterstitialAd {
            ad.present(fromRootViewController: self) {
                let reward = ad.adReward
                print("Reward received with currency \(reward.amount), amount \(reward.amount.doubleValue)")
                self.earnCoins(reward.amount.intValue)
            }
        } else {
            print("Ad wasn't ready")
        }
    }
    
}

extension ViewController : GADBannerViewDelegate, GADFullScreenContentDelegate {
    
    // For Interstitial Ad
    
    func loadInterstitialAd() {
        let adUnitID = "ca-app-pub-3940256099942544/4411468910"
        let request = GADRequest()
        
        GADInterstitialAd.load(withAdUnitID: adUnitID, request: request) { ad, error in
            if let error = error {
                print("Failed to load interstitial ad with error: \(error.localizedDescription)")
                return
            }
            
            self.interstitial = ad
            self.interstitial?.fullScreenContentDelegate = self
        }
    }
    
    func showInterstitialAd() {
        if let ad = interstitial {
            ad.present(fromRootViewController: self)
        } else {
            print("Ad wasn't ready")
        }
    }
    
    // For Reward Ad
    
    func addloadrewardedInterstitialAd() {
        GADRewardedInterstitialAd.load(withAdUnitID:"ca-app-pub-3940256099942544/6978759866",
                                       request: GADRequest()) { ad, error in
            if let error = error {
                return print("Failed to load rewarded interstitial ad with error: \(error.localizedDescription)")
            }
            
            self.rewardedInterstitialAd = ad
            self.rewardedInterstitialAd?.fullScreenContentDelegate = self
        }
        
    }
    private func earnCoins(_ coins: NSInteger) {
        coinCount += coins
        coinCountLabel.text = "Coins: \(self.coinCount)"
    }
    
    
}
