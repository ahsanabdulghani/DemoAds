////
////  CheckViewController.swift
////  DemoAds
////
////  Created by MacBook Pro on 06/12/2023.
////
//import UIKit
//import GoogleMobileAds
//
//class CheckViewController: UIViewController {
//
//
//    @IBOutlet weak var adView: GADNativeAdView!
//
//    var adLoader: GADAdLoader!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        adLoader = GADAdLoader(adUnitID: "ca-app-pub-3940256099942544/3986624511",
//                              rootViewController: self,
//                              adTypes: [GADAdLoaderAdType.unifiedNative],
//                              options: nil)
//        adLoader.delegate = self
//        adLoader.load(GADRequest())
//    }
//}
//
//extension CheckViewController: GADAdLoaderDelegate {
//
//    func adLoader(_ adLoader: GADAdLoader, didReceive nativeAd: GADUnifiedNativeAd) {
//        // Populate the native ad view with the ad assets.
//        // Customize the following lines based on your ad view layout.
//
//        // Register the native ad view and the headline and media views.
//        adView.nativeAd = nativeAd
//        adView.headlineView = adView.headlineView
//        adView.mediaView = adView.mediaView
//
//        // Populate other ad assets, such as the body and call to action.
//        // adView.bodyView = ...
//
//        // Associate the native ad view with the native ad object. This is
//        // required to make the ad clickable.
//        adView.callToActionView?.isUserInteractionEnabled = false
//        adView.callToActionView?.isHidden = true
//    }
//
//    func adLoader(_ adLoader: GADAdLoader, didFailToReceiveAdWithError error: Error) {
//        if let error = error as? GADRequestError {
//            print("Ad failed to load with error: \(error.localizedDescription)")
//        } else {
//            print("Ad failed to load with unknown error")
//        }
//    }
//}
